#!/bin/bash

IMAGE_DIR="$1"

mkdir -p "$IMAGE_DIR"

if ! command -v curl &> /dev/null
then
    echo "curl could not be found. Please install curl."
    exit
fi

if [ "$#" -lt 1 ]; then
    echo "Usage: $0 <user_id1> <user_id2> ..."
    exit 1
fi

for USER_ID in "$@"
do
    USER_DATA=$(curl -s "https://reqres.in/api/users/$USER_ID")
    
    if [ "$(echo "$USER_DATA" | jq '.data | length')" -eq 0 ]; then
        echo "User ID $USER_ID not found."
        continue
    fi

ID=$(echo "$USER_DATA" | grep -o '"id": *"[^"]*' | cut -d'"' -f4)
FIRST_NAME=$(echo "$USER_DATA" | grep -o '"first_name": *"[^"]*' | cut -d'"' -f4)
LAST_NAME=$(echo "$USER_DATA" | grep -o '"last_name": *"[^"]*' | cut -d'"' -f4)
AVATAR_URL=$(echo "$USER_DATA" | grep -o '"avatar": *"[^"]*' | cut -d'"' -f4)


    FILE_NAME="${ID}_${FIRST_NAME}_${LAST_NAME}.jpg"
    
    curl -s "$AVATAR_URL" -o "${IMAGE_DIR}/${FILE_NAME}"
    
    echo "Downloaded image for user ID $USER_ID to ${IMAGE_DIR}/${FILE_NAME}"
done


log_file="download_log_$(date +"%Y%m%d%H%M%S").txt"
touch "$log_file" || 
    { 
     echo "Failed to create log file $log_file";
     exit 1;
     }

current_time=$(date +"%Y-%m-%d %T.%N")
username=$(whoami)
branch_name=$(git branch --show-current)
echo "Username: $username" >> "$log_file"
echo "Current Git Branch: $branch_name" >> "$log_file"
echo "Operation Time: $current_time" >> "$log_file"
echo "Operation Details: Downloaded user images to directory $DIRECTORY" >> "$log_file"

