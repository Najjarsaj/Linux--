#!/bin/bash

usage() {
    echo "Usage: $0 --play <playlist_name> | --list [playlist_names...] | --url <url> --folderPath <folder_path> --filename <file_name> --resolution <resolution>"
    exit 1
}

install_mpv() {
    if ! command -v mpv &> /dev/null; then
        echo "MPV is not installed. Installing MPV..."
        sudo apt update
        sudo apt install -y mpv
    else
        echo "MPV is already installed."
    fi
}

create_m3u_playlist() {
    local playlist_name="$1"
    local folder_path="$2"
    local playlist_file="${playlist_name}_playlist.m3u"

    > "$playlist_file"
    for file in "$folder_path"/*; do
        if [[ -f "$file" && ("$file" == *.mp4 || "$file" == *.mp3 || "$file" == *.mkv || "$file" == *.avi) ]]; then
            echo "$file" >> "$playlist_file"
        fi
    done

    echo "$playlist_file"
}

play_playlist() {
    local playlist_file="$1"
    mpv --playlist="$playlist_file"
}

list_playlists() {
    local playlist_names=("$@")

    if [ ${#playlist_names[@]} -eq 0 ]; then
        playlist_names=(*)
    fi

    for playlist_name in "${playlist_names[@]}"; do
        if [ -d "$playlist_name" ]; then
            echo "Playlist: $playlist_name"
            echo "Folder: $(pwd)/$playlist_name"
            echo "Files:"
            ls -1 "$playlist_name"
            echo ""
        else
            echo "Playlist folder '$playlist_name' does not exist."
        fi
    done
}

setup_virtualenv() {
    if [ ! -d "venv" ]; then
        python3 -m venv venv
    fi
    source venv/bin/activate
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt
    else
        pip install pytube
    fi
}

download_video() {
    local url="$1"
    local folder_name="$2"
    local file_name="$3"
    local resolution="$4"

    setup_virtualenv

    if [[ "$file_name" == *.mp3 ]]; then
        is_audio_only="true"
        resolution=""
    elif [[ "$file_name" == *.mp4 ]]; then
        is_audio_only="false"
    else
        echo "Invalid file extension. Supported extensions are .mp3 and .mp4."
        exit 1
    fi

    if [ ! -d "$folder_name" ]; then
        mkdir -p "$folder_name"
    fi

    playlist_name=$(basename "$folder_name")

    index_file="playlists_index.txt"
    if [ ! -f "$index_file" ]; then
        touch "$index_file"
    fi

    if ! grep -q "$playlist_name" "$index_file"; then
        echo "$playlist_name: $folder_name" >> "$index_file"
    fi

    python3 youtubedownloader.py "$url" "$folder_name" "$file_name" "$is_audio_only" "$resolution" &

    pid=$!
    echo "Downloading..."
    while kill -0 $pid 2>/dev/null; do
        printf '.'
        sleep 1
    done
    echo "Download complete."

    deactivate
}

if [ "$1" == "--play" ]; then
    if [ -z "$2" ]; then
        echo "Please provide the playlist name."
        exit 1
    fi
    playlist_name="$2"
    folder_path="$(pwd)/$playlist_name"

    if [ ! -d "$folder_path" ]; then
        echo "Playlist folder '$folder_path' does not exist."
        exit 1
    fi

    install_mpv
    playlist_file=$(create_m3u_playlist "$playlist_name" "$folder_path")
    play_playlist "$playlist_file"

elif [ "$1" == "--list" ]; then
    shift
    list_playlists "$@"

elif [ "$1" == "--url" ] || [ "$1" == "-u" ]; then
    if [ $# -lt 7 ]; then
        echo "Usage: $0 --url <url> --folderPath <folder_path> --filename <file_name> --resolution <resolution>"
        exit 1
    fi
    url=""
    folder_name=""
    file_name=""
    resolution=""

    while [ $# -gt 0 ]; do
        case "$1" in
            --url|-u)
                url="$2"
                shift 2
                ;;
            --folderPath|-d)
                folder_name="$2"
                shift 2
                ;;
            --filename|-f)
                file_name="$2"
                shift 2
                ;;
            --resolution|-r)
                resolution="$2"
                shift 2
                ;;
            *)
                echo "Invalid option: $1"
                exit 1
                ;;
        esac
    done

    if [ -z "$url" ] || [ -z "$folder_name" ] || [ -z "$file_name" ]; then
        usage
    fi

    download_video "$url" "$folder_name" "$file_name" "$resolution"

else
    usage
fi

