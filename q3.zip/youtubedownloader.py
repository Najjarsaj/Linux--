import argparse
from pytube import YouTube
from pytube.exceptions import PytubeError
import ssl

# פתרון זמני לבעיית SSL (לא מומלץ לשימוש קבוע)
ssl._create_default_https_context = ssl._create_unverified_context

def download_video(url, folder_name, file_name, is_audio_only, resolution):
    try:
        yt = YouTube(url)
    except PytubeError as e:
        print(f"Failed to fetch video: {e}")
        return

    try:
        if is_audio_only.lower() == 'true':
            stream = yt.streams.filter(only_audio=True).first()
        else:
            stream = yt.streams.filter(res=resolution, file_extension='mp4').first()

        if stream:
            output_path = stream.download(output_path=folder_name, filename=file_name)
            print(f"Downloaded finish: {output_path}")
        else:
            print("Resolution availability Error.")
    except PytubeError as e:
        print(f"Download failed: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Download YouTube videos or audio.")
    parser.add_argument("url", help="URL of the YouTube video")
    parser.add_argument("folder_name", help="Folder path to save the downloaded file")
    parser.add_argument("file_name", help="File name for the downloaded file")
    parser.add_argument("is_audio_only", help="Download audio only: 'true' or 'false'")
    parser.add_argument("resolution", nargs='?', default='', help="Resolution of the video (e.g., '720p')")

    args = parser.parse_args()

    download_video(args.url, args.folder_name, args.file_name, args.is_audio_only, args.resolution)