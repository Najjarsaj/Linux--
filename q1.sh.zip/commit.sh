#!/bin/bash

excel_file="./file.csv"

current_branch=$(git rev-parse --abbrev-ref HEAD)

dev_name=$(git config user.name)

priority=$(awk -F',' -v branch="$current_branch" '$4==branch {print $3}' "$excel_file")

bug_id=$(awk -F',' -v branch="$current_branch" '$4==branch {print $1}' "$excel_file")

current_datetime=$(date +"%Y-%m-%d %H:%M:%S")

excel_description=$(awk -F',' -v branch="$current_branch" '$4==branch {print $5}' "$excel_file")

dev_description="$1"

commit_message="BugID:$bug_id:$current_datetime:$current_branch:$dev_name:$priority:$excel_description:$dev_description"

git add .
git commit -m "$commit_message"

if git push origin "$current_branch"; then
  echo "Push successful"
else
  echo "Error: Push failed"
fi